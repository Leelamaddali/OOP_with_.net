﻿namespace Lab_3Application
{
    partial class Calculations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SelectEquation = new System.Windows.Forms.GroupBox();
            this.DivisionRadio = new System.Windows.Forms.RadioButton();
            this.MultiplicationRadio = new System.Windows.Forms.RadioButton();
            this.SubtractionRadio = new System.Windows.Forms.RadioButton();
            this.AdditionRadio = new System.Windows.Forms.RadioButton();
            this.Question = new System.Windows.Forms.GroupBox();
            this.number2 = new System.Windows.Forms.Label();
            this.number1 = new System.Windows.Forms.Label();
            this.EqualLabel = new System.Windows.Forms.Label();
            this.OperationLabel = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.DecisionBox = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.AnswerBox = new System.Windows.Forms.GroupBox();
            this.Result = new System.Windows.Forms.Label();
            this.SelectEquation.SuspendLayout();
            this.Question.SuspendLayout();
            this.DecisionBox.SuspendLayout();
            this.AnswerBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // SelectEquation
            // 
            this.SelectEquation.AccessibleDescription = "";
            this.SelectEquation.Controls.Add(this.DivisionRadio);
            this.SelectEquation.Controls.Add(this.MultiplicationRadio);
            this.SelectEquation.Controls.Add(this.SubtractionRadio);
            this.SelectEquation.Controls.Add(this.AdditionRadio);
            this.SelectEquation.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectEquation.Location = new System.Drawing.Point(22, 22);
            this.SelectEquation.Name = "SelectEquation";
            this.SelectEquation.Size = new System.Drawing.Size(810, 143);
            this.SelectEquation.TabIndex = 0;
            this.SelectEquation.TabStop = false;
            this.SelectEquation.Tag = "";
            this.SelectEquation.Text = "Select an equation type";
            // 
            // DivisionRadio
            // 
            this.DivisionRadio.AutoSize = true;
            this.DivisionRadio.Location = new System.Drawing.Point(575, 57);
            this.DivisionRadio.Name = "DivisionRadio";
            this.DivisionRadio.Size = new System.Drawing.Size(115, 31);
            this.DivisionRadio.TabIndex = 3;
            this.DivisionRadio.TabStop = true;
            this.DivisionRadio.Text = "Division";
            this.DivisionRadio.UseVisualStyleBackColor = true;
            this.DivisionRadio.CheckedChanged += new System.EventHandler(this.DivisionRadio_CheckedChanged);
            // 
            // MultiplicationRadio
            // 
            this.MultiplicationRadio.AutoSize = true;
            this.MultiplicationRadio.Location = new System.Drawing.Point(378, 57);
            this.MultiplicationRadio.Name = "MultiplicationRadio";
            this.MultiplicationRadio.Size = new System.Drawing.Size(173, 31);
            this.MultiplicationRadio.TabIndex = 2;
            this.MultiplicationRadio.TabStop = true;
            this.MultiplicationRadio.Text = "Multiplication";
            this.MultiplicationRadio.UseVisualStyleBackColor = true;
            this.MultiplicationRadio.CheckedChanged += new System.EventHandler(this.MultiplicationRadio_CheckedChanged);
            // 
            // SubtractionRadio
            // 
            this.SubtractionRadio.AutoSize = true;
            this.SubtractionRadio.Location = new System.Drawing.Point(180, 57);
            this.SubtractionRadio.Name = "SubtractionRadio";
            this.SubtractionRadio.Size = new System.Drawing.Size(156, 31);
            this.SubtractionRadio.TabIndex = 1;
            this.SubtractionRadio.TabStop = true;
            this.SubtractionRadio.Text = "Subtraction";
            this.SubtractionRadio.UseVisualStyleBackColor = true;
            this.SubtractionRadio.CheckedChanged += new System.EventHandler(this.SubtractionRadio_CheckedChanged);
            // 
            // AdditionRadio
            // 
            this.AdditionRadio.AutoSize = true;
            this.AdditionRadio.Location = new System.Drawing.Point(24, 57);
            this.AdditionRadio.Name = "AdditionRadio";
            this.AdditionRadio.Size = new System.Drawing.Size(120, 31);
            this.AdditionRadio.TabIndex = 0;
            this.AdditionRadio.TabStop = true;
            this.AdditionRadio.Text = "Addition";
            this.AdditionRadio.UseVisualStyleBackColor = true;
            this.AdditionRadio.CheckedChanged += new System.EventHandler(this.AdditionRadio_CheckedChanged_1);
            // 
            // Question
            // 
            this.Question.Controls.Add(this.number2);
            this.Question.Controls.Add(this.number1);
            this.Question.Controls.Add(this.EqualLabel);
            this.Question.Controls.Add(this.OperationLabel);
            this.Question.Controls.Add(this.textBox3);
            this.Question.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Question.Location = new System.Drawing.Point(22, 182);
            this.Question.Name = "Question";
            this.Question.Size = new System.Drawing.Size(810, 124);
            this.Question.TabIndex = 1;
            this.Question.TabStop = false;
            this.Question.Text = "Can you answer this question?";
            // 
            // number2
            // 
            this.number2.AutoSize = true;
            this.number2.Location = new System.Drawing.Point(340, 55);
            this.number2.Name = "number2";
            this.number2.Size = new System.Drawing.Size(0, 27);
            this.number2.TabIndex = 6;
            // 
            // number1
            // 
            this.number1.AutoSize = true;
            this.number1.Location = new System.Drawing.Point(45, 55);
            this.number1.Name = "number1";
            this.number1.Size = new System.Drawing.Size(0, 27);
            this.number1.TabIndex = 5;
            this.number1.Click += new System.EventHandler(this.number1_Click_1);
            // 
            // EqualLabel
            // 
            this.EqualLabel.AutoSize = true;
            this.EqualLabel.Location = new System.Drawing.Point(478, 58);
            this.EqualLabel.Name = "EqualLabel";
            this.EqualLabel.Size = new System.Drawing.Size(26, 27);
            this.EqualLabel.TabIndex = 4;
            this.EqualLabel.Text = "=";
            // 
            // OperationLabel
            // 
            this.OperationLabel.AutoSize = true;
            this.OperationLabel.Location = new System.Drawing.Point(197, 55);
            this.OperationLabel.Name = "OperationLabel";
            this.OperationLabel.Size = new System.Drawing.Size(0, 27);
            this.OperationLabel.TabIndex = 3;
            this.OperationLabel.Click += new System.EventHandler(this.OperationLabel_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(554, 55);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 34);
            this.textBox3.TabIndex = 2;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // DecisionBox
            // 
            this.DecisionBox.Controls.Add(this.button3);
            this.DecisionBox.Controls.Add(this.button2);
            this.DecisionBox.Controls.Add(this.button1);
            this.DecisionBox.Location = new System.Drawing.Point(22, 327);
            this.DecisionBox.Name = "DecisionBox";
            this.DecisionBox.Size = new System.Drawing.Size(810, 111);
            this.DecisionBox.TabIndex = 2;
            this.DecisionBox.TabStop = false;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(528, 43);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(153, 40);
            this.button3.TabIndex = 2;
            this.button3.Text = "I\'m done";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(304, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(173, 40);
            this.button2.TabIndex = 1;
            this.button2.Text = "Am I Right?";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(69, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 40);
            this.button1.TabIndex = 0;
            this.button1.Text = "Next Question";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AnswerBox
            // 
            this.AnswerBox.Controls.Add(this.Result);
            this.AnswerBox.Location = new System.Drawing.Point(22, 452);
            this.AnswerBox.Name = "AnswerBox";
            this.AnswerBox.Size = new System.Drawing.Size(810, 82);
            this.AnswerBox.TabIndex = 3;
            this.AnswerBox.TabStop = false;
            // 
            // Result
            // 
            this.Result.AutoSize = true;
            this.Result.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result.Location = new System.Drawing.Point(252, 40);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(0, 27);
            this.Result.TabIndex = 0;
            // 
            // Calculations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 546);
            this.Controls.Add(this.AnswerBox);
            this.Controls.Add(this.DecisionBox);
            this.Controls.Add(this.Question);
            this.Controls.Add(this.SelectEquation);
            this.Name = "Calculations";
            this.Text = "Math Practice";
            this.Load += new System.EventHandler(this.Calculations_Load);
            this.SelectEquation.ResumeLayout(false);
            this.SelectEquation.PerformLayout();
            this.Question.ResumeLayout(false);
            this.Question.PerformLayout();
            this.DecisionBox.ResumeLayout(false);
            this.AnswerBox.ResumeLayout(false);
            this.AnswerBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox SelectEquation;
        private System.Windows.Forms.RadioButton DivisionRadio;
        private System.Windows.Forms.RadioButton MultiplicationRadio;
        private System.Windows.Forms.RadioButton SubtractionRadio;
        private System.Windows.Forms.RadioButton AdditionRadio;
        private System.Windows.Forms.GroupBox Question;
        private System.Windows.Forms.Label EqualLabel;
        private System.Windows.Forms.Label OperationLabel;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox DecisionBox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox AnswerBox;
        private System.Windows.Forms.Label Result;
        private System.Windows.Forms.Label number2;
        private System.Windows.Forms.Label number1;
    }
}

