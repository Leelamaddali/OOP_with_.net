﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3Application
{
    public partial class Calculations : Form
    {
        Random rand = new Random();
        public Calculations()
        {
            InitializeComponent();
        }



        public void Calculations_Load(object sender, EventArgs e)
        {
            int num1 = rand.Next(1, 10);
            int num2 = rand.Next(1, 10);

            number1.Text = num1.ToString();
            number2.Text = num2.ToString();

        }

        private void SubtractionRadio_CheckedChanged(object sender, EventArgs e)
        {
            OperationLabel.Text = "-";

            textBox3.Text = String.Empty;
            Result.Text = String.Empty;
        }

        private void AdditionRadio_CheckedChanged_1(object sender, EventArgs e)
        {
            OperationLabel.Text = "+";

            textBox3.Text = String.Empty;
            Result.Text = String.Empty;
        }

        private void MultiplicationRadio_CheckedChanged(object sender, EventArgs e)
        {
            OperationLabel.Text = "*";

            textBox3.Text = String.Empty;
            Result.Text = String.Empty;


        }

        private void DivisionRadio_CheckedChanged(object sender, EventArgs e)
        {
            OperationLabel.Text = "/";
            textBox3.Text = String.Empty;
            Result.Text = String.Empty;

        }

        private void number1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (AdditionRadio.Checked == true)
            {

                int value1 = int.TryParse(number1.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(textBox3.Text, out value3) ? value3 : 1;

                int result = value1 + value2;

                if (value3 == result)
                {
                    Result.Text = "Correct";
                }
                else
                {
                    Result.Text = "Incorrect. Correct answer is " + result;
                }

            }


            if (SubtractionRadio.Checked == true)
            {

                int value1 = int.TryParse(number1.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(textBox3.Text, out value3) ? value3 : 1;

                int result = value1 - value2;

                if (value3 == result)
                {
                    Result.Text = "Correct";
                }
                else
                {
                    Result.Text = "Incorrect. Correct answer is " + result;
                }

            }


            if (MultiplicationRadio.Checked == true)
            {

                int value1 = int.TryParse(number1.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(textBox3.Text, out value3) ? value3 : 1;

                int result = value1 * value2;

                if (value3 == result)
                {
                    Result.Text = "Correct";
                }
                else
                {
                    Result.Text = "Incorrect. Correct answer is " + result;
                }

            }


            if (DivisionRadio.Checked == true)
            {

                int value1 = int.TryParse(number1.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(textBox3.Text, out value3) ? value3 : 1;

                int result = value1 / value2;

                if (value3 == result)
                {
                    Result.Text = "Correct";
                }
                else
                {
                    Result.Text = "Incorrect. Correct answer is " + result;
                }




            }



        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int num1 = rand.Next(1, 10);
            int num2 = rand.Next(1, 10);

            number1.Text = num1.ToString();
            number2.Text = num2.ToString();

            textBox3.Text = String.Empty;
            Result.Text = String.Empty;

        }

        private void number1_Click_1(object sender, EventArgs e)
        {

        }

        private void OperationLabel_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
